# Renmoe 樣式快速查詢表

| ID | 名稱 | 類別 | 複雜度 | 元素數 | 特徵 |
|----|----|------|--------|--------|------|
| `blog_1` | Blog 101 | Blog | medium | 11 | ima, loo |
| `blog_3` | Blog 102 | Blog | simple | 9 | loo, bac |
| `blog_5` | Blog 277 | Blog | medium | 16 | ima, loo |
| `blog_7` | Blog 471 | Blog | simple | 9 | loo, bac |
| `blog_9` | Blog 534 | Blog | medium | 17 | ima, loo |
| `blog_11` | Blog 694 | Blog | medium | 14 | but, ima, loo |
| `blog_13` | Blog 835 | Blog | medium | 15 | but, ima, loo |
| `blog_15` | Blog 944 | Blog | simple | 9 | loo, bac |
| `cta_157` | CTA 163 | CTA | simple | 9 | but, bac |
| `cta_159` | CTA 169 | CTA | simple | 8 | but |
| `cta_161` | CTA 244 | CTA | medium | 14 | but |
| `cta_163` | CTA 265 | CTA | simple | 8 | but |
| `cta_165` | CTA 347 | CTA | simple | 9 | but, bac |
| `cta_167` | CTA 473 | CTA | simple | 10 | but, ima |
| `cta_169` | CTA 587 | CTA | simple | 8 | but, bac |
| `cta_171` | CTA 599 | CTA | simple | 8 | but |
| `cta_173` | CTA 623 | CTA | medium | 12 | but, ima |
| `cta_175` | CTA 683 | CTA | medium | 12 | but, ima |
| `cta_177` | CTA 734 | CTA | medium | 11 | but, ima, bac |
| `cta_179` | CTA 834 | CTA | simple | 10 | but |
| `cta_181` | CTA 845 | CTA | simple | 8 | for |
| `cta_183` | CTA 932 | CTA | simple | 10 | but |
| `cta_185` | CTA 945 | CTA | simple | 10 | for, ima |
| `contact_17` | Contact 274 | Contact | simple | 9 | for |
| `contact_21` | Contact 734 | Contact | simple | 9 | for, ima |
| `contact_23` | Contact 833 | Contact | simple | 9 | for, ima |
| `contact_25` | Contact 934 | Contact | simple | 9 | for |
| `contact_27` | Contact 984 | Contact | simple | 9 | for, ima |
| `content_29` | Content 081 | Content | complex | 23 | but, ima |
| `content_31` | Content 083 | Content | medium | 14 | but, ima |
| `content_33` | Content 085 | Content | medium | 15 | but, ima |
| `content_35` | Content 094 | Content | medium | 11 | but, ima |
| `content_37` | Content 111 | Content | medium | 11 | but, ima |
| `content_39` | Content 113 | Content | medium | 11 | but, ima |
| `content_41` | Content 114 | Content | medium | 14 | but, ima |
| `content_43` | Content 115 | Content | simple | 8 | ima, bac |
| `content_45` | Content 116 | Content | simple | 10 | but, ima |
| `content_47` | Content 117 | Content | medium | 13 | but, ima |
| `content_None` | Content 118 | Content | complex | 21 | ima, bac |
| `content_49` | Content 156 | Content | medium | 13 | but |
| `content_None` | Content 162 | Content | complex | 33 | ima, bac |
| `content_None` | Content 165 | Content | complex | 21 | bac |
| `content_51` | Content 174 | Content | simple | 7 | ima |
| `content_53` | Content 175 | Content | medium | 11 | ima |
| `content_55` | Content 183 | Content | complex | 28 | ima |
| `content_57` | Content 186 | Content | medium | 11 | but, ima |
| `content_59` | Content 194 | Content | medium | 15 | bac |
| `content_None` | Content 227 | Content | complex | 22 | ima, bac |
| `content_61` | Content 234 | Content | simple | 8 | ima |
| `content_63` | Content 238 | Content | simple | 9 | but, ima |
| `content_None` | Content 267 | Content | complex | 31 | but, bac |
| `content_65` | Content 275 | Content | medium | 18 | ima |
| `content_67` | Content 278 | Content | simple | 7 |  |
| `content_69` | Content 285 | Content | simple | 10 | ima |
| `content_None` | Content 291 | Content | complex | 24 | ima |
| `content_71` | Content 320 | Content | simple | 7 |  |
| `content_None` | Content 325 | Content | complex | 22 | ima, bac |
| `content_None` | Content 335 | Content | complex | 30 | bac |
| `content_None` | Content 353 | Content | complex | 26 | but, bac |
| `content_73` | Content 354 | Content | medium | 18 | but, ima |
| `content_None` | Content 363 | Content | complex | 33 | ima |
| `content_None` | Content 367 | Content | complex | 31 | but, bac |
| `content_None` | Content 374 | Content | complex | 29 | but, bac |
| `content_75` | Content 378 | Content | medium | 11 | but, ima |
| `content_77` | Content 383 | Content | medium | 12 | but |
| `content_None` | Content 448 | Content | medium | 20 | bac |
| `content_79` | Content 462 | Content | medium | 15 | but, ima |
| `content_81` | Content 463 | Content | simple | 10 |  |
| `content_83` | Content 464 | Content | medium | 11 | but, ima |
| `content_85` | Content 472 | Content | medium | 14 | but |
| `content_None` | Content 521 | Content | complex | 21 | but, ima |
| `content_87` | Content 554 | Content | complex | 30 | bac |
| `content_89` | Content 578 | Content | simple | 9 |  |
| `content_91` | Content 694 | Content | simple | 7 | ima |
| `content_93` | Content 695 | Content | simple | 7 |  |
| `content_95` | Content 716 | Content | simple | 10 | but |
| `content_97` | Content 717 | Content | simple | 10 | ima |
| `content_99` | Content 726 | Content | medium | 13 | but, ima |
| `content_101` | Content 734 | Content | medium | 11 | but |
| `content_103` | Content 772 | Content | simple | 8 |  |
| `content_105` | Content 820 | Content | simple | 7 | ima |
| `content_107` | Content 821 | Content | medium | 12 | ima |
| `content_109` | Content 822 | Content | simple | 7 |  |
| `content_111` | Content 823 | Content | simple | 10 |  |
| `content_113` | Content 831 | Content | simple | 8 | but |
| `content_None` | Content 832 | Content | complex | 29 | but, bac |
| `content_115` | Content 834 | Content | medium | 14 | but, ima |
| `content_117` | Content 883 | Content | medium | 20 | but, ima |
| `content_119` | Content 884 | Content | simple | 10 |  |
| `content_121` | Content 885 | Content | complex | 25 | ima |
| `content_123` | Content 888 | Content | complex | 26 | but, ima |
| `content_125` | Content 889 | Content | medium | 16 | ima |
| `content_127` | Content 890 | Content | simple | 7 | bac |
| `content_129` | Content 893 | Content | simple | 6 | bac |
| `content_None` | Content 894 | Content | complex | 25 | but, ima, bac |
| `content_131` | Content 901 | Content | complex | 48 | but, ima |
| `content_None` | Content 912 | Content | complex | 22 | ima, bac |
| `content_133` | Content 931 | Content | complex | 23 | ima |
| `content_135` | Content 932 | Content | simple | 5 | bac |
| `content_137` | Content 934 | Content | medium | 15 | but, ima |
| `content_139` | Content 935 | Content | medium | 16 | but, ima |
| `content_141` | Content 936 | Content | complex | 52 | ima |
| `content_145` | Content 971 | Content | simple | 6 | but |
| `content_147` | Content 982 | Content | medium | 11 | but, ima |
| `content_149` | Content 993 | Content | medium | 20 | but, ima |
| `content_151` | Content 994 | Content | simple | 8 | but, bac |
| `content_153` | Content 995 | Content | complex | 25 | ima |
| `content_155` | Content 998 | Content | medium | 17 | ima |
| `faq_187` | FAQ 223 | FAQ | simple | 6 |  |
| `faq_189` | FAQ 234 | FAQ | simple | 6 |  |
| `faq_191` | FAQ 251 | FAQ | complex | 38 | ima |
| `faq_193` | FAQ 274 | FAQ | complex | 70 |  |
| `faq_195` | FAQ 322 | FAQ | complex | 39 | but |
| `faq_197` | FAQ 344 | FAQ | complex | 39 | but |
| `faq_199` | FAQ 352 | FAQ | simple | 6 |  |
| `faq_201` | FAQ 453 | FAQ | complex | 39 | but |
| `faq_203` | FAQ 834 | FAQ | simple | 6 |  |
| `faq_205` | FAQ 972 | FAQ | complex | 141 |  |
| `footer_207` | Footer 183 | Footer | complex | 21 |  |
| `footer_209` | Footer 243 | Footer | complex | 30 | for |
| `footer_211` | Footer 263 | Footer | simple | 8 |  |
| `footer_213` | Footer 344 | Footer | complex | 32 | for |
| `footer_215` | Footer 629 | Footer | medium | 15 | bac |
| `footer_217` | Footer 723 | Footer | simple | 8 |  |
| `footer_219` | Footer 762 | Footer | medium | 17 |  |
| `footer_221` | Footer 773 | Footer | medium | 15 |  |
| `footer_223` | Footer 931 | Footer | complex | 22 | for |
| `footer_225` | Footer 934 | Footer | medium | 19 | for |
| `gallery_227` | Gallery 112 | Gallery | simple | 9 | ima |
| `gallery_229` | Gallery 116 | Gallery | medium | 11 | ima |
| `gallery_233` | Gallery 343 | Gallery | medium | 19 | ima |
| `gallery_235` | Gallery 723 | Gallery | medium | 11 | ima |
| `gallery_237` | Gallery 727 | Gallery | medium | 11 | ima |
| `gallery_239` | Gallery 733 | Gallery | medium | 12 | ima |
| `gallery_241` | Gallery 834 | Gallery | complex | 23 | but, ima |
| `gallery_243` | Gallery 873 | Gallery | complex | 23 | but, ima |
| `gallery_245` | Gallery 993 | Gallery | complex | 23 | but, ima |
| `grid_None` | Grid 01 | Grid | simple | 5 |  |
| `grid_None` | Grid 02 | Grid | simple | 6 |  |
| `grid_None` | Grid 03 | Grid | simple | 7 |  |
| `grid_None` | Grid 04 | Grid | simple | 7 |  |
| `grid_None` | Grid 05 | Grid | simple | 8 |  |
| `grid_None` | Grid 06 | Grid | simple | 8 |  |
| `header_None` | Header 01 | Header | complex | 36 |  |
| `header_None` | Header 02 | Header | complex | 37 | but, ima, bac |
| `header_None` | Header 03 | Header | complex | 58 | but, ima, bac |
| `header_None` | Header 04 | Header | complex | 45 | but, bac |
| `header_None` | Header 05 | Header | medium | 17 | but |
| `header_None` | Header 06 | Header | complex | 31 | but |
| `header_None` | Header 07 | Header | complex | 29 | but |
| `header_None` | Header 08 | Header | complex | 44 | but, ima, loo |
| `header_None` | Header 09 | Header | complex | 42 | but, ima, loo |
| `header_None` | Header 10 | Header | complex | 49 | but, bac |
| `header_None` | Header 11 | Header | complex | 31 | but, bac |
| `header_None` | Header 12 | Header | complex | 22 | but, bac |
| `header_None` | Header 13 | Header | complex | 26 |  |
| `header_None` | Header 16 | Header | complex | 34 | ima, loo, bac |
| `header_247` | Header 162 | Header | simple | 6 |  |
| `header_253` | Header 262 | Header | simple | 5 |  |
| `header_255` | Header 332 | Header | simple | 8 | but |
| `header_259` | Header 476 | Header | simple | 8 | but, bac |
| `header_261` | Header 534 | Header | simple | 8 | but, bac |
| `header_265` | Header 728 | Header | simple | 9 | but |
| `hero_273` | Hero 101 | Hero | medium | 11 | but, ima, bac |
| `hero_275` | Hero 109 | Hero | simple | 9 | for, bac |
| `hero_277` | Hero 110 | Hero | simple | 10 | but, bac |
| `hero_279` | Hero 147 | Hero | medium | 11 | but, ima |
| `hero_281` | Hero 148 | Hero | medium | 11 | but |
| `hero_283` | Hero 162 | Hero | simple | 8 | but, bac |
| `hero_None` | Hero 163 | Hero | simple | 7 |  |
| `hero_None` | Hero 173 | Hero | simple | 8 | for |
| `hero_None` | Hero 238 | Hero | simple | 7 | bac |
| `hero_None` | Hero 262 | Hero | simple | 5 |  |
| `hero_285` | Hero 274 | Hero | simple | 10 | but, ima |
| `hero_None` | Hero 332 | Hero | simple | 10 | but |
| `hero_None` | Hero 362 | Hero | simple | 8 | but |
| `hero_287` | Hero 372 | Hero | simple | 8 | but, bac |
| `hero_289` | Hero 386 | Hero | complex | 26 | but, ima |
| `hero_291` | Hero 450 | Hero | simple | 10 | for, bac |
| `hero_293` | Hero 451 | Hero | simple | 10 | for, bac |
| `hero_295` | Hero 452 | Hero | simple | 10 | for, bac |
| `hero_297` | Hero 453 | Hero | simple | 10 | for, bac |
| `hero_299` | Hero 472 | Hero | medium | 16 | but, bac |
| `hero_None` | Hero 476 | Hero | simple | 8 | but, bac |
| `hero_301` | Hero 523 | Hero | simple | 10 | but, ima |
| `hero_303` | Hero 529 | Hero | complex | 26 | but, bac |
| `hero_None` | Hero 534 | Hero | simple | 10 | but, bac |
| `hero_305` | Hero 603 | Hero | medium | 11 | but, bac |
| `hero_307` | Hero 604 | Hero | medium | 11 | but, bac |
| `hero_309` | Hero 632 | Hero | medium | 11 | but, bac |
| `hero_311` | Hero 693 | Hero | medium | 11 | but, ima |
| `hero_313` | Hero 723 | Hero | medium | 12 | but, ima |
| `hero_315` | Hero 724 | Hero | medium | 12 | but, ima |
| `hero_317` | Hero 725 | Hero | medium | 13 | but, ima |
| `hero_319` | Hero 726 | Hero | medium | 13 | but, ima |
| `hero_321` | Hero 727 | Hero | medium | 11 | but, ima, bac |
| `hero_323` | Hero 728 | Hero | simple | 10 | but |
| `hero_325` | Hero 729 | Hero | medium | 12 | but, ima |
| `hero_None` | Hero 730 | Hero | simple | 10 | but |
| `hero_None` | Hero 739 | Hero | simple | 6 | for |
| `hero_327` | Hero 832 | Hero | medium | 15 | but, bac |
| `hero_329` | Hero 834 | Hero | simple | 9 | but, ima, bac |
| `hero_331` | Hero 846 | Hero | simple | 10 | for, ima |
| `hero_333` | Hero 847 | Hero | simple | 10 | for |
| `hero_335` | Hero 922 | Hero | simple | 10 | but |
| `hero_337` | Hero 923 | Hero | medium | 11 | but, ima, bac |
| `hero_339` | Hero 924 | Hero | medium | 18 | but |
| `hero_341` | Hero 925 | Hero | simple | 8 | ima |
| `hero_None` | Hero 943 | Hero | simple | 8 | for |
| `hero_343` | Hero 990 | Hero | medium | 11 | but, bac |
| `hero_345` | Hero 991 | Hero | medium | 11 | but, bac |
| `logo_347` | Logo 318 | Logo | medium | 18 | ima |
| `logo_349` | Logo 622 | Logo | simple | 10 | ima |
| `logo_351` | Logo 834 | Logo | simple | 10 | ima |
| `logo_353` | Logo 915 | Logo | medium | 17 | but, ima |
| `navbar_355` | Navbar 237 | Navbar | medium | 19 | but, bac |
| `navbar_357` | Navbar 283 | Navbar | complex | 34 | but, bac |
| `navbar_359` | Navbar 351 | Navbar | complex | 55 | but, bac |
| `navbar_363` | Navbar 772 | Navbar | complex | 34 | but, bac |
| `portfolio_369` | Portfolio 175 | Portfolio | complex | 21 | ima |
| `portfolio_371` | Portfolio 564 | Portfolio | medium | 20 | but, ima, bac |
| `portfolio_373` | Portfolio 624 | Portfolio | complex | 22 | but, ima, bac |
| `portfolio_375` | Portfolio 735 | Portfolio | complex | 22 | but, ima, bac |
| `portfolio_377` | Portfolio 782 | Portfolio | complex | 39 | but, ima |
| `portfolio_379` | Portfolio 823 | Portfolio | medium | 15 | ima |
| `portfolio_381` | Portfolio 834 | Portfolio | medium | 19 | ima |
| `portfolio_383` | Portfolio 931 | Portfolio | medium | 19 | ima |
| `portfolio_385` | Portfolio 934 | Portfolio | complex | 23 | but, ima |
| `pricing_387` | Pricing 148 | Pricing | medium | 15 | but |
| `pricing_389` | Pricing 258 | Pricing | medium | 16 | but |
| `pricing_391` | Pricing 384 | Pricing | complex | 27 | but |
| `pricing_393` | Pricing 484 | Pricing | complex | 29 | but |
| `pricing_395` | Pricing 537 | Pricing | medium | 13 | but |
| `pricing_397` | Pricing 638 | Pricing | medium | 20 | but |
| `pricing_399` | Pricing 749 | Pricing | complex | 23 | but |
| `pricing_401` | Pricing 853 | Pricing | complex | 36 | but |
| `product_None` | Product List 1 | Product | medium | 13 | ima, loo |
| `product_None` | Product List 2 | Product | medium | 19 | but, ima, loo |
| `product_None` | Product List 3 | Product | medium | 19 | but, ima, loo |
| `product_None` | Product List 4 | Product | medium | 15 | ima, loo |
| `product_None` | Product List 5 | Product | medium | 20 | but, ima, loo |
| `product_None` | Product List 6 | Product | medium | 16 | but, ima, loo |
| `single_None` | Single Product Header 1 | Single | medium | 14 |  |
| `single_None` | Single Product Header 2 | Single | complex | 32 |  |
| `single_None` | Single Product Header 4 | Single | medium | 14 |  |
| `single_None` | Single Product Header 7 | Single | medium | 14 |  |
| `single_None` | Single Product Header 8 | Single | complex | 29 |  |
| `team_403` | Team 362 | Team | complex | 54 | ima |
| `team_405` | Team 476 | Team | complex | 30 | ima |
| `team_407` | Team 527 | Team | complex | 37 | but, ima |
| `team_409` | Team 627 | Team | complex | 42 | ima |
| `team_411` | Team 742 | Team | complex | 30 | ima |
| `team_413` | Team 844 | Team | complex | 37 | but, ima |
| `testimonial_415` | Testimonial 152 | Testimonial | simple | 4 |  |
| `testimonial_417` | Testimonial 192 | Testimonial | complex | 27 | ima |
| `testimonial_419` | Testimonial 242 | Testimonial | complex | 33 | ima |
| `testimonial_421` | Testimonial 261 | Testimonial | simple | 6 | ima |
| `testimonial_423` | Testimonial 372 | Testimonial | simple | 4 |  |
| `testimonial_425` | Testimonial 478 | Testimonial | simple | 6 |  |
| `testimonial_427` | Testimonial 512 | Testimonial | complex | 27 | ima |
| `testimonial_429` | Testimonial 583 | Testimonial | simple | 7 |  |
| `testimonial_431` | Testimonial 622 | Testimonial | complex | 27 | ima |
| `testimonial_435` | Testimonial 721 | Testimonial | complex | 61 | ima |
| `testimonial_437` | Testimonial 883 | Testimonial | complex | 33 | ima |