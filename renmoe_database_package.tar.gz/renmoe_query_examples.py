#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Renmoe 樣式資料庫查詢範例腳本
"""

import json
from pathlib import Path

# 載入資料庫
DB_PATH = Path(__file__).parent / 'renmoe_styles_database.json'

with open(DB_PATH, 'r', encoding='utf-8') as f:
    db = json.load(f)

def search_by_category(category):
    """按類別搜尋樣式"""
    return [s for s in db['styles'] if s['category'].lower() == category.lower()]

def search_by_feature(feature):
    """按特徵搜尋 (如 'form', 'button', 'image')"""
    feature_key = f'has_{feature}'
    return [s for s in db['styles'] if feature_key in s['metadata']['features']]

def search_by_complexity(complexity):
    """按複雜度搜尋 ('simple', 'medium', 'complex')"""
    return [s for s in db['styles'] if s['complexity'] == complexity]

def get_style_by_id(style_id):
    """通過 ID 獲取樣式"""
    return next((s for s in db['styles'] if s['id'] == style_id), None)

def get_recommendations_for_page(page_type):
    """為特定頁面類型推薦樣式組合"""
    recommendations = {}
    
    if page_type == 'landing_page':
        recommendations['hero'] = search_by_category('Hero')[:3]
        recommendations['content'] = search_by_category('Content')[:5]
        recommendations['cta'] = search_by_category('CTA')[:2]
        recommendations['testimonial'] = search_by_category('Testimonial')[:2]
        recommendations['faq'] = search_by_category('FAQ')[:1]
        recommendations['footer'] = search_by_category('Footer')[:1]
    
    elif page_type == 'blog':
        recommendations['header'] = search_by_category('Header')[:1]
        recommendations['hero'] = search_by_category('Hero')[:1]
        recommendations['blog_list'] = search_by_category('Blog')[:3]
        recommendations['footer'] = search_by_category('Footer')[:1]
    
    return recommendations

# 互動式查詢
if __name__ == '__main__':
    print("🔍 Renmoe 樣式資料庫查詢工具\n")
    print(f"資料庫包含 {len(db['styles'])} 個樣式\n")
    
    print("可用類別:")
    for cat, count in sorted(db['metadata']['categories'].items()):
        print(f"  - {cat} ({count} 個)")
    
    print("\n範例查詢:")
    print("1. search_by_category('Hero')")
    print("2. search_by_feature('form')")
    print("3. search_by_complexity('simple')")
    print("4. get_style_by_id('hero_110')")
    print("5. get_recommendations_for_page('landing_page')")
    
    # 示範查詢
    print("\n--- 示範:找出所有包含表單的樣式 ---")
    form_styles = search_by_feature('form')
    print(f"找到 {len(form_styles)} 個樣式:")
    for s in form_styles[:5]:
        print(f"  - {s['name']} ({s['category']})")
